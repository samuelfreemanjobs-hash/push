# Vertical pack — Etsy digital seller

**Agent:** Client Onboarding

## Use this context in every workflow
- **Audience:** Sells templates, printables, or digital downloads on Etsy
- **Core pain:** Listings not ranking, inconsistent launches, overwhelmed by SEO and photos
- **Example offer:** Agent kits + Excel command center
- **Primary channel:** Pinterest + Etsy search

## Suggested inputs for workflow 01 (welcome-email-draft)
Paste into the workflow inputs before the agent brief:

```
Niche: Etsy digital seller
Offer: Agent kits + Excel command center
Audience: Sells templates, printables, or digital downloads on Etsy
Primary channel: Pinterest + Etsy search
Brand voice: direct, trustworthy, no hype
```

## Niche tips
- N/A for productized buyers; use for B2B template licensing only.

## Etsy listing angle (if you sell this agent)
Title lead with outcome for **etsy digital seller** buyers, not generic "AI prompts."
